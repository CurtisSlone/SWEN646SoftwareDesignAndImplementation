package com.gui;

import com.manager.Manager;
import java.awt.event.*;

public class SelectingPanel extends State {

    public SelectingPanel(Manager parentManager){
        super(parentManager);
    }

    public void actionPerformed(ActionEvent ae){ };
}
