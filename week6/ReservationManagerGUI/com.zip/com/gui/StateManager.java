package com.gui;

import java.awt.*;
import javax.swing.*;

public class StateManager {

}
