package com.gui;

import com.manager.Manager;
import java.awt.event.*;

public class UpdateObject extends State {
    
    public UpdateObject(Manager parent, String type){
        super(parent);
        
    }

    public void actionPerformed(ActionEvent ae){};
}
