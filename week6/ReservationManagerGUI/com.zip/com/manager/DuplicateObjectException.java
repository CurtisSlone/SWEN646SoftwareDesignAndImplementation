package com.manager;

class DuplicateObjectException extends RuntimeException {
    public DuplicateObjectException(String message){
        super(message);
    }
}
