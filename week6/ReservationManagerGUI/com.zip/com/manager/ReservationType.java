package com.manager;

public enum ReservationType {
    HOTEL,
    CABIN,
    HOUSE
}
