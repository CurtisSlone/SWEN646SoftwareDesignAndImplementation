package com.manager;

class IllegalLoadException extends RuntimeException {
    public IllegalLoadException(String message){
        super(message);
    }
}
