package com.manager;

enum ReservationStatus {
    DRAFT,
    COMPLETED,
    CANCELLED
}
