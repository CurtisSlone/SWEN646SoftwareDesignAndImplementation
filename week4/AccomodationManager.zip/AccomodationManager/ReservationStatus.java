package reservationmanager;

public enum ReservationStatus {
    DRAFT,
    COMPLETED,
    CANCELLED
}
