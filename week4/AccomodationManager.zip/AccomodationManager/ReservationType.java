package reservationmanager;

public enum ReservationType {
    HOTEL,
    CABIN,
    HOUSE
}
