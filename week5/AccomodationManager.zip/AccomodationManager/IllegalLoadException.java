package reservationmanager;

class IllegalLoadException extends RuntimeException {
    public IllegalLoadException(String message){
        super(message);
    }
}
