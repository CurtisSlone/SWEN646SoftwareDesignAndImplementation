package reservationmanager;

enum ReservationStatus {
    DRAFT,
    COMPLETED,
    CANCELLED
}
